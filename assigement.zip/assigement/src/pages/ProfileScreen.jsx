import React from 'react';

const ProfileScreen = () => {
  return (
    <div className="profile-page-container">
      <div className="profile-header">
        <h2>Account Settings</h2>
      </div>

      <div className="profile-details-card">
        <div className="profile-pic-container">
          <img 
            src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=2564&auto=format&fit=crop" 
            alt="Profile" 
            className="profile-pic" 
          />
          <div className="camera-icon">
            <i class="fa-solid fa-camera"></i>
            </div>
        </div>
        <div className="profile-info">
          <h3>Ankush Chauhan</h3>
          <p>abc@gmail.com</p>
        </div>
      </div>
      
      <div className="profile-description">
        <p>
          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore voluptas repudiandae cum voluptatum dicta, commodi labore adipisci non maiores animi fugit mollitia laboriosam laborum impedit, tempora corrupti illo temporibus nesciunt?
          Totam quasi at quam ad, eum ea ab laboriosam voluptates sequi earum consequatur, non ex saepe optio minus aspernatur sapiente.
        </p>
      </div>
      
      <hr className="divider" />
    </div>
  );
};

export default ProfileScreen;